package com.fst.fst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FstApplicationTests {

	@Test
	void contextLoads() {
	}

}
